<?php
require 'config.php';
echo json_encode(["status" => "Database connected successfully"]);
?>
